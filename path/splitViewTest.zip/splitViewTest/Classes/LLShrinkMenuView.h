//
//  LLShrinkMenuView.h
//  splitViewTest
//
//  Created by  on 12-4-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLShrinkMenuView : UIView

@end






@interface LLShrinkMenuItem : UIImageView 
{
	float _fAngle; //弧度
	float _endPoint;  //
}
@end