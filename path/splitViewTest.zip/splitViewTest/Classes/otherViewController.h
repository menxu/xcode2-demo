//
//  otherViewController.h
//  splitViewTest
//
//  Created by kindy_imac on 12-4-10.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface otherViewController : UITableViewController 
{

}

@end
