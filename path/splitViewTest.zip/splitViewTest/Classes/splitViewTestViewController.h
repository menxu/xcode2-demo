//
//  splitViewTestViewController.h
//  splitViewTest
//
//  Created by kindy_imac on 12-3-14.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface splitViewTestViewController : UIViewController {

}

@end

